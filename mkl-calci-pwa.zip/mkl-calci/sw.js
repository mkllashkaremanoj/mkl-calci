
const CACHE_NAME = 'mkl-calc-v1';
const OFFLINE_URL = '/mkl-calci/';
const ASSETS = [
  OFFLINE_URL,
  '/mkl-calci/index.html',
  '/mkl-calci/manifest.json',
  '/mkl-calci/sw.js',
  '/mkl-calci/icons/icon-192.png',
  '/mkl-calci/icons/icon-512.png'
];

// Install - cache app shell
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

// Activate - cleanup old caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
    ))
  );
  self.clients.claim();
});

// Fetch - try cache, then network, fallback to cached offline page
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(cachedResp => {
      if (cachedResp) return cachedResp;
      return fetch(event.request).then(networkResp => {
        return networkResp;
      }).catch(() => caches.match(OFFLINE_URL));
    })
  );
});
